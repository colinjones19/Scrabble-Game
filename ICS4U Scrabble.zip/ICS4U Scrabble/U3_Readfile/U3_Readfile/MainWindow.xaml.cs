﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace U3_Readfile
    /// Colin Jones
    /// ISC4U
    /// April 28, 2018 
    /// Reads All english words, and checks scrabble letters to see if any fit.

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            

            System.Net.WebClient webClient = new System.Net.WebClient(); 
            string url = "http://darcy.rsgc.on.ca/ACES/ICS4U/SourceCode/Words.txt";  // Found URL
            webClient.BaseAddress = url;
            System.IO.StreamReader streamReader = new System.IO.StreamReader(webClient.OpenRead(url));
            System.IO.StreamWriter streamWriter = new System.IO.StreamWriter("words.txt");  // Get my words, boi

            try
            {
                while (!streamReader.EndOfStream) 
                {
                    string word = streamReader.ReadLine();
                    if (word.Length < 8)
                    {
                        streamWriter.Write(word.ToUpper() + "\r" + "\n");
                    }
                }
                streamWriter.Flush();
                streamWriter.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
